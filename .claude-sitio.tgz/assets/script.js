// VantTS — sitio de una sola página (v3, 18 oct 2026)
document.documentElement.classList.add("js");

// Menú superior: botón de menú en celular, borde al bajar y sección activa.
(function () {
  const nav = document.getElementById("nav");
  const boton = document.getElementById("navBoton");
  const links = document.getElementById("navLinks");
  if (!nav || !boton || !links) return;

  function cerrar() {
    links.classList.remove("abierto");
    boton.setAttribute("aria-expanded", "false");
    boton.setAttribute("aria-label", "Abrir menú");
  }
  boton.addEventListener("click", () => {
    const abierto = links.classList.toggle("abierto");
    boton.setAttribute("aria-expanded", String(abierto));
    boton.setAttribute("aria-label", abierto ? "Cerrar menú" : "Abrir menú");
  });
  links.querySelectorAll("a").forEach((a) => a.addEventListener("click", cerrar));
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") cerrar(); });
  document.addEventListener("click", (e) => { if (!nav.contains(e.target)) cerrar(); });

  const enlaces = Array.from(links.querySelectorAll("a[data-seccion]"));
  const secciones = enlaces.map((a) => document.getElementById(a.dataset.seccion)).filter(Boolean);
  function actualizar() {
    nav.classList.toggle("con-borde", window.scrollY > 8);
    const linea = window.innerHeight * 0.35;
    let actual = null;
    secciones.forEach((s) => { if (s.getBoundingClientRect().top <= linea) actual = s; });
    if (secciones.length && secciones[secciones.length - 1].getBoundingClientRect().bottom < linea) actual = null;
    enlaces.forEach((a) => a.classList.toggle("activa", !!actual && a.dataset.seccion === actual.id));
  }
  window.addEventListener("scroll", actualizar, { passive: true });
  window.addEventListener("resize", actualizar);
  actualizar();
})();

// Pestañas de "Cómo funciona" (con flechas del teclado).
(function () {
  const tabs = Array.from(document.querySelectorAll('.tabs [role="tab"]'));
  if (!tabs.length) return;
  function elegir(tab, foco) {
    tabs.forEach((t) => {
      const sel = t === tab;
      t.setAttribute("aria-selected", String(sel));
      t.tabIndex = sel ? 0 : -1;
      const panel = document.getElementById(t.getAttribute("aria-controls"));
      if (!panel) return;
      panel.hidden = !sel;
      if (sel) { panel.classList.remove("entra"); void panel.offsetWidth; panel.classList.add("entra"); }
    });
    if (foco) tab.focus();
    tab.scrollIntoView({ block: "nearest", inline: "center", behavior: "smooth" });
  }
  tabs.forEach((t, i) => {
    t.addEventListener("click", () => elegir(t, false));
    t.addEventListener("keydown", (e) => {
      if (e.key === "ArrowRight") { e.preventDefault(); elegir(tabs[(i + 1) % tabs.length], true); }
      if (e.key === "ArrowLeft") { e.preventDefault(); elegir(tabs[(i - 1 + tabs.length) % tabs.length], true); }
    });
  });
})();

// Aparición suave de tarjetas al bajar (se respeta "reducir movimiento").
(function () {
  const items = document.querySelectorAll(".revelar");
  if (!("IntersectionObserver" in window)) { items.forEach((el) => el.classList.add("visto")); return; }
  const obs = new IntersectionObserver((entradas) => {
    entradas.forEach((en) => { if (en.isIntersecting) { en.target.classList.add("visto"); obs.unobserve(en.target); } });
  }, { rootMargin: "0px 0px -8% 0px" });
  items.forEach((el) => obs.observe(el));
})();

// Botón "Subir": aparece al bajar y regresa al inicio.
(function () {
  const subir = document.getElementById("subir");
  if (!subir) return;
  function revisar() { subir.classList.toggle("visible", window.scrollY > 700); }
  window.addEventListener("scroll", revisar, { passive: true });
  revisar();
  subir.addEventListener("click", (e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: "smooth" }); });
})();

// Detalle completo de cada plan: ventana con pestañas (Básico, Pro, Max, Ultra).
(function () {
  const dlg = document.getElementById("planDialogo");
  if (!dlg || typeof dlg.showModal !== "function") return;
  const tabs = Array.from(dlg.querySelectorAll('[role="tab"]'));
  const cuerpo = dlg.querySelector(".pd-cuerpo");
  let origen = null;

  function mostrar(pid, foco) {
    tabs.forEach((t) => {
      const sel = t.dataset.plan === pid;
      t.setAttribute("aria-selected", String(sel));
      t.tabIndex = sel ? 0 : -1;
      const panel = document.getElementById(t.getAttribute("aria-controls"));
      if (!panel) return;
      panel.hidden = !sel;
      if (sel) { panel.classList.remove("entra"); void panel.offsetWidth; panel.classList.add("entra"); }
      if (sel && foco) t.focus();
    });
    if (cuerpo) cuerpo.scrollTop = 0;
  }
  function abrir(pid, boton) {
    origen = boton;
    mostrar(pid, false);
    dlg.showModal();
    document.body.classList.add("con-dialogo");
    const sel = tabs.find((t) => t.dataset.plan === pid);
    if (sel) sel.focus();
  }
  document.querySelectorAll(".plan-ver").forEach((b) => b.addEventListener("click", () => abrir(b.dataset.plan, b)));
  tabs.forEach((t, i) => {
    t.addEventListener("click", () => mostrar(t.dataset.plan, false));
    t.addEventListener("keydown", (e) => {
      if (e.key === "ArrowRight") { e.preventDefault(); mostrar(tabs[(i + 1) % tabs.length].dataset.plan, true); }
      if (e.key === "ArrowLeft") { e.preventDefault(); mostrar(tabs[(i - 1 + tabs.length) % tabs.length].dataset.plan, true); }
    });
  });
  dlg.querySelectorAll("[data-cerrar]").forEach((b) => b.addEventListener("click", () => dlg.close()));
  // Cerrar al tocar fuera de la caja.
  dlg.addEventListener("click", (e) => { if (e.target === dlg) dlg.close(); });
  dlg.addEventListener("close", () => {
    document.body.classList.remove("con-dialogo");
    if (origen) origen.focus();
  });
})();

// Calculadora de precios de VantTS Barber (4 nov 2026): Pro y Max con IVA
// según los barberos con cuenta, y lo que se iría en comisiones por
// clientes nuevos en una app que cobra un porcentaje de la primera cita.
(function () {
  const calc = document.getElementById("calculadora");
  if (!calc) return;
  const num = (id, min, max) => {
    const v = Math.round(Number(document.getElementById(id).value));
    return Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : min;
  };
  const pesos = (n) => "$" + Math.round(n).toLocaleString("es-MX");
  const pro = Number(calc.dataset.pro), max = Number(calc.dataset.max);
  const extra = Number(calc.dataset.extra), pct = Number(calc.dataset.comision);
  function actualizar() {
    const barberos = num("calcBarberos", 1, 30);
    const nuevos = num("calcNuevos", 0, 999);
    const corte = num("calcCorte", 0, 9999);
    const adicional = extra * (barberos - 1);
    document.getElementById("calcPro").textContent = pesos(pro + adicional);
    document.getElementById("calcMax").textContent = pesos(max + adicional);
    document.getElementById("calcComision").textContent =
      "Si una app te cobrara " + pct + " % de la primera cita de cada cliente nuevo, se te irían " +
      pesos((nuevos * corte * pct) / 100) + " al mes.";
  }
  calc.querySelectorAll("input").forEach((i) => i.addEventListener("input", actualizar));
  actualizar();
})();
